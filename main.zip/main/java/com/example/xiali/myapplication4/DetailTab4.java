package com.example.xiali.myapplication4;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DetailTab4 extends Fragment {
    private JSONparse jsonParseAsyncTask=new JSONparse();
    private String upcomingjson;
    private RecyclerView list;
    private RecyclerView.LayoutManager layoutManager;
    private Spinner leftspinner;
    private Spinner rightspinner;
    private String leftchoice;
    private String rightchoice;
    private List<UpcomingBean> upcominglist;
    Adapterforupcoming adapter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.detailtab4,container,false);
        list= (RecyclerView)view.findViewById(R.id.upcoming_here);
        list.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getContext());
        list.setLayoutManager(layoutManager);
        leftspinner = (Spinner) view.findViewById(R.id.leftspin);
        rightspinner= (Spinner) view.findViewById(R.id.rightspin);

        rightspinner.setEnabled(false);

        leftspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(parent.getItemAtPosition(position).toString().equals("Default")){
                    rightspinner.setEnabled(false);
                    leftchoice=parent.getItemAtPosition(position).toString();
                }else{
                    leftchoice=parent.getItemAtPosition(position).toString();
                    rightspinner.setEnabled(true);

                }

                if(leftchoice.equals("Event Name")&&rightchoice.equals("Ascending")) {
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o1.getEventname().compareTo(o2.getEventname());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);

                }
                if(leftchoice.equals("Event Name")&&rightchoice.equals("Descending")){
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o2.getEventname().compareTo(o1.getEventname());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);
                }

                if(leftchoice.equals("Artist")&&rightchoice.equals("Ascending")) {
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o1.getArtists().compareTo(o2.getArtists());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);

                }

                if(leftchoice.equals("Artist")&&rightchoice.equals("Descending")){
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o2.getArtists().compareTo(o1.getArtists());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);
                }

                if(leftchoice.equals("Type")&&rightchoice.equals("Descending")){
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o2.getType().compareTo(o1.getType());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);
                }

                if(leftchoice.equals("Type")&&rightchoice.equals("Ascending")){
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o1.getType().compareTo(o2.getType());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);
                }
                if(leftchoice.equals("Time")&&rightchoice.equals("Ascending")){
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o1.getDateandtime().compareTo(o2.getDateandtime());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);
                }
                if(leftchoice.equals("Time")&&rightchoice.equals("Descending")){
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o2.getDateandtime().compareTo(o1.getDateandtime());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);
                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        rightspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                rightchoice=parent.getItemAtPosition(position).toString();

                if(leftchoice.equals("Event Name")&&rightchoice.equals("Ascending")) {
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o1.getEventname().compareTo(o2.getEventname());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);

                }
                if(leftchoice.equals("Event Name")&&rightchoice.equals("Descending")){
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o2.getEventname().compareTo(o1.getEventname());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);
                }

                if(leftchoice.equals("Artist")&&rightchoice.equals("Ascending")) {
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o1.getArtists().compareTo(o2.getArtists());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);

                }

                if(leftchoice.equals("Artist")&&rightchoice.equals("Descending")){
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o2.getArtists().compareTo(o1.getArtists());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);
                }

                if(leftchoice.equals("Type")&&rightchoice.equals("Descending")){
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o2.getType().compareTo(o1.getType());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);
                }

                if(leftchoice.equals("Type")&&rightchoice.equals("Ascending")){
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o1.getType().compareTo(o2.getType());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);
                }
                if(leftchoice.equals("Time")&&rightchoice.equals("Ascending")){
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o1.getDateandtime().compareTo(o2.getDateandtime());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);
                }
                if(leftchoice.equals("Time")&&rightchoice.equals("Descending")){
                    Collections.sort(upcominglist, new Comparator<UpcomingBean>() {
                        @Override
                        public int compare(UpcomingBean o1, UpcomingBean o2) {
                            return o2.getDateandtime().compareTo(o1.getDateandtime());
                        }
                    });
                    Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
                    list.setAdapter(adapter);
                }



            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });





        jsonParseAsyncTask.execute("hi");
        return view;





    }




    private class JSONparse extends AsyncTask<String,String,String> {


        private Map<String,String> detailmap = new HashMap<String,String>();

        private ProgressDialog pDialog;


        protected void onPreExecute() {
            super.onPreExecute();


            pDialog = new ProgressDialog(getActivity());
            pDialog.setMessage("Getting Data ...");
            pDialog.setCancelable(true);
            pDialog.show();
        }

        protected String doInBackground(String... params) {

            //detailjson = ConnectServer.getJson("http://10.0.2.2:3000/eventdetail");

            //musicjson = ConnectServer.getJson("http://10.0.2.2:3000/musician");

            //music is not finish yet;

            //sportsjson=ConnectServer.getJson("http://10.0.2.2:3000/sports");
            //venuejson=ConnectServer.getJson("http://10.0.2.2:3000/venuedetail");
            upcomingjson=ConnectServer.getJson("http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/upcoming02");


            //get JSON here;
            return upcomingjson;

        }

        @Override
        protected void onPostExecute(String upcomingjson) {
            upcominglist = new ArrayList<UpcomingBean>();
            //textView.setText(resultlist.toString());


            try {
                JSONObject upcomingJSON = new JSONObject(upcomingjson);
                JSONArray events = upcomingJSON.getJSONObject("resultsPage").getJSONObject("results")
                        .getJSONArray("event");
                int max = Math.min(events.length(),5);
                for(int i=0;i<max;i++){
                    UpcomingBean current = new UpcomingBean();
                    JSONObject current_json = events.getJSONObject(i);
                    String nameandtime = current_json.getString("displayName");
                    current.setEventname(nameandtime);

                    String artist_ = current_json.getJSONArray("performance").getJSONObject(0)
                            .getJSONObject("artist").getString("displayName");
                    current.setArtists(artist_);

                    String datebefore =current_json.getJSONObject("start").getString("date");


                    //format the time here;

                    String dt = datebefore+" "+
                                current_json.getJSONObject("start").getString("time");
                    current.setDateandtime(dt);

                    String tp = "Type: "+current_json.getString("type");
                    current.setUrl(current_json.getString("uri"));
                    current.setType(tp);
                    upcominglist.add(current);

                }






            }catch(JSONException e){
                e.printStackTrace();
            }

            super.onPostExecute(upcomingjson);
            if (pDialog.isShowing()) pDialog.dismiss();
            Adapterforupcoming adapter = new Adapterforupcoming(upcominglist);
            list.setAdapter(adapter);

            if(upcominglist.size()==0){
                TextView textView= (TextView)getActivity().findViewById(R.id.norecordsup);
                textView.setVisibility(View.VISIBLE);



            }else{
                TextView textView= (TextView)getActivity().findViewById(R.id.norecordsup);
                textView.setVisibility(View.INVISIBLE);

            }




        }

    }
}
