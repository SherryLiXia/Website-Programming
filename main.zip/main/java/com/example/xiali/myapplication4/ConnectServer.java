package com.example.xiali.myapplication4;

import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ConnectServer {


    public static boolean submitform(final Searchbean searchbean){

        new Thread(){
            public void run(){
                HttpURLConnection conn = null;
                try{
                    //searchbean.getKeyword();
                    String url = "http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/endpoint?keyword="+searchbean.getKeyword()
                            +"&category="+searchbean.getCategory()
                            +"&remote="+searchbean.getRemote()+"&lathere="+searchbean.getLat()
                            +"&lonhere="+searchbean.getLng()+"&distance="+searchbean.getDistance()
                            +"&mileorkm="+searchbean.getMileorkm();
                    URL urL = new URL(url);
                    conn = (HttpURLConnection)urL.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);
                    conn.setUseCaches(false);
                    Integer a = conn.getResponseCode();
                    Log.i("44444444","code ="+a);

                    if(conn.getResponseCode()==200){
                        InputStream in = new BufferedInputStream(conn.getInputStream());
                        String success="success";
                        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(in));
                        String line;
                        StringBuffer buffer = new StringBuffer();
                        while((line=bufferedReader.readLine())!=null){
                            buffer.append(line);
                        }
                        String str=buffer.toString();

                    }
                    else{
                        System.out.println("error connection");

                    }
                }catch (MalformedURLException e){

                    e.printStackTrace();

                }catch(IOException e){

                    e.printStackTrace();

                }
                finally{
                    if(conn!=null){
                        conn.disconnect();
                    }
                }

            }
        }.start();



            return true;
        }

    public static boolean submiteventid(final String eventid){
        new Thread(){
            public void run(){
                HttpURLConnection conn = null;
                try{

                    String url="http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/endpoint2?eventid="+eventid;
                    URL urL = new URL(url);
                    conn = (HttpURLConnection)urL.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);
                    conn.setUseCaches(false);
                    Integer a = conn.getResponseCode();
                    Log.i("44444444","code ="+a);

                    if(conn.getResponseCode()==200){
                        InputStream in = new BufferedInputStream(conn.getInputStream());
                        String success="success";
                        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(in));
                        String line;
                        StringBuffer buffer = new StringBuffer();
                        while((line=bufferedReader.readLine())!=null){
                            buffer.append(line);
                        }
                        String str=buffer.toString();

                    }
                    else{
                        System.out.println("error connection");

                    }



                }catch(MalformedURLException e){
                    e.printStackTrace();
                }catch(IOException e){
                    e.printStackTrace();
                }finally {

                        if(conn!=null){
                            conn.disconnect();
                        }

                }
            }

        }.start();
        return true;
    }

    public static String getJson(final String url2){

            String str="";

                HttpURLConnection connection = null;
                try{
                    URL urL = new URL(url2);
                    connection = (HttpURLConnection)urL.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(5000);
                    connection.setUseCaches(false);
                    Integer a = connection.getResponseCode();
                    Log.i("44444444","code ="+a);
                    //set connection;


                    if(connection.getResponseCode()==200){
                        InputStream is = new BufferedInputStream(connection.getInputStream());
                        String success="success";
                        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(is));
                        String line;
                        StringBuffer buffer = new StringBuffer();
                        while((line=bufferedReader.readLine())!=null){
                            buffer.append(line);
                        }
                        str=buffer.toString();
                        //get json into String;





                    }
                    else{
                        System.out.println("error connection");

                    }





                }catch(MalformedURLException e){
                    e.printStackTrace();
                }catch(IOException e){
                    e.printStackTrace();
                }
                finally{
                    if(connection!=null){
                        connection.disconnect();
                    }
                }

         return str;
    }






    }



