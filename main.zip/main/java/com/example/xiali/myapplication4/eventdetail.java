package com.example.xiali.myapplication4;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class eventdetail extends AppCompatActivity {
    private String detailjson;
    private String musicjson;
    private String sportsjson;

    private String venuejson;
    private String upcomingjson;

    private Toolbar edtoolbar;
    private MenuItem twitter;
    private MenuItem favorite;
    private Menu menu;
    private String eventname;
    private String venue;
    private String buytickat1;
    private String category1;
    private JSONparse jsonParseAsyncTask=new JSONparse();
    private Toolbar toolbar;
    private String time1;
    private String eventid;
    private DbHelper dbHelper;




    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */
    private SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventdetail);



        toolbar = (Toolbar) findViewById(R.id.eventdetailtoolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        dbHelper = new DbHelper(this);





        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.Detailtabs);

        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(mViewPager));

        jsonParseAsyncTask.execute("hi");



    }



   public void opentwitter(MenuItem item){


        String introtext="Check out ";
        introtext = introtext+eventname;
        introtext = introtext+" at"+venue+". ";
        String website = buytickat1;
        introtext = introtext+"Website; "+website+" #CSCI571event search";



        String twitterurl ="https://twitter.com/intent/tweet?text="+introtext;


       Uri uri = Uri.parse(twitterurl);
       Intent intent = new Intent(Intent.ACTION_VIEW,uri);
       startActivity(intent);
        //twitter here

   }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_eventdetail, menu);
        this.menu = menu;
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        public PlaceholderFragment() {

        }

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_eventdetail, container, false);
            TextView textView = (TextView) rootView.findViewById(R.id.section_label);
            textView.setText(getString(R.string.section_format, getArguments().getInt(ARG_SECTION_NUMBER)));
            return rootView;
        }
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentStatePagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            switch (position){
                case 0:

                    DetailTab1 tab1= new DetailTab1();


                    Bundle bundle1=new Bundle();
                    bundle1.putString("detailjson",detailjson);
                    tab1.setArguments(bundle1);




                    return tab1;
                case 1:
                    DetailTab2 tab2= new DetailTab2();
                    return tab2;

                case 2:
                    DetailTab3 tab3 = new DetailTab3();
                    return tab3;
                case 3:
                    DetailTab4 tab4 =  new DetailTab4();
                    return tab4;
            }
            return null;
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 4;
        }


    }



    private class JSONparse extends AsyncTask<String,String,String> {


        private Map<String,String> detailmap = new HashMap<String,String>();

        private ProgressDialog pDialog;


        protected void onPreExecute() {
            super.onPreExecute();


            pDialog = new ProgressDialog(eventdetail.this);
            pDialog.setMessage("Getting Data ...");
            pDialog.setCancelable(true);
            pDialog.show();
        }

        protected String doInBackground(String... params) {

            detailjson = ConnectServer.getJson("http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/eventdetail");

            //musicjson = ConnectServer.getJson("http://10.0.2.2:3000/musician");

            //music is not finish yet;

            //sportsjson=ConnectServer.getJson("http://10.0.2.2:3000/sports");
            //venuejson=ConnectServer.getJson("http://10.0.2.2:3000/venuedetail");
            //String text = ConnectServer.getJson("http://10.0.2.2:3000/upcoming01");
            //upcomingjson=ConnectServer.getJson("http://10.0.2.2:3000/upcoming02");

            String text = ConnectServer.getJson("http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/upcoming01");

            //get JSON here;
            return detailjson;

        }

        @Override
        protected void onPostExecute(String detailjson) {
            JSONObject detailJSON = new JSONObject();
            //textView.setText(resultlist.toString());
            super.onPostExecute(detailjson);
            if (pDialog.isShowing()) pDialog.dismiss();

            try {
                detailJSON = new JSONObject(detailjson);
            }catch(JSONException e){
                e.printStackTrace();
            }
            try {

                if(detailJSON.has("name"))
                    eventname = detailJSON.getString("name");
                if(detailJSON.has("_embedded")&&detailJSON.getJSONObject("_embedded").has("venues")) {
                   venue = detailJSON.getJSONObject("_embedded").getJSONArray("venues").getJSONObject(0).getString("name");

                }


                if(detailJSON.has("url")){
                    buytickat1 = detailJSON.getString("url");


                }
                if(detailJSON.has("classifications")){
                    category1 = detailJSON.getJSONArray("classifications").getJSONObject(0).getJSONObject("segment").getString("name");
                    category1=category1+"|"+ detailJSON.getJSONArray("classifications").getJSONObject(0).getJSONObject("genre").getString("name");


                }
                if(detailJSON.has("dates")) {
                    if(detailJSON.getJSONObject("dates").has("start")&&detailJSON.getJSONObject("dates").getJSONObject("start").has("localDate")) {
                        time1 = detailJSON.getJSONObject("dates").getJSONObject("start").getString("localDate")
                                + " " + detailJSON.getJSONObject("dates").getJSONObject("start").getString("localTime");

                    }

                }
                if(detailJSON.has("id")){
                    eventid = detailJSON.getString("id");
                }



            }catch(JSONException e){
                e.printStackTrace();
            }

            toolbar.setTitle(eventname);

            if(dbHelper.contains(eventid)){
                menu.getItem(0).setIcon(R.drawable.favorite_red);
            }

            menu.getItem(0).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    if(dbHelper.contains(eventid)){
                        menu.getItem(0).setIcon(R.drawable.favorite_white);
                        dbHelper.deleteEvent(eventid);
                        String show = eventname+" has been removed from favorite";
                        Toast.makeText(eventdetail.this, show, Toast.LENGTH_SHORT).show();

                    }else{
                       menu.getItem(0).setIcon(R.drawable.favorite_red);
                        dbHelper.insertEvent(eventid,eventname,category1,venue,time1);
                        String show = eventname+" has been added to favorite";
                        Toast.makeText(eventdetail.this, show, Toast.LENGTH_SHORT).show();


                    }




                    return false;
                }
            });





        }

    }





    }




