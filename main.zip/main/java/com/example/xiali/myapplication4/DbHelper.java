package com.example.xiali.myapplication4;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;

public class DbHelper extends SQLiteOpenHelper {
     public static final String DATABASE_NAME = "MyDBName.db";
     public static final String EVENTS_TABLE_NAME ="events";
     public static final String EVENTS_COL_ID = "eventid";
     public static final String EVENTS_COL_NAME ="eventname";
     public static final String EVENTS_COL_TYPE ="type";
     public static final String EVENTS_COL_VENUE="venue";
     public static final String EVENTS_COL_DATE ="date";
     private HashMap hp;

     public DbHelper(Context context){
         super(context,DATABASE_NAME,null,1);
     }

     @Override
    public void onCreate(SQLiteDatabase db){
         db.execSQL(
                 "create table events"
                 +"(eventid text, eventname text, type text, venue text, date text)"
         );
     }

     @Override
    public void onUpgrade(SQLiteDatabase db,int oldVersion, int newVersion){
         db.execSQL("DROP TABLE IF EXISTS events");
         onCreate(db);
     }

     public boolean insertEvent(String eventid,String eventname,String type,String venue,String date){
         SQLiteDatabase db = this.getWritableDatabase();
         ContentValues contentValues = new ContentValues();
         contentValues.put("eventid",eventid);
         contentValues.put("eventname",eventname);
         contentValues.put("type",type);
         contentValues.put("venue",venue);
         contentValues.put("date",date);
         db.insert("events",null,contentValues);
         return true;
     }

     public Cursor getData(String id){
         SQLiteDatabase db = this.getReadableDatabase();
         Cursor res = db.rawQuery("select * from events where eventid ="+id+"",null);
         return res;
     }

     public int numberOfRows(){
         SQLiteDatabase db = this.getReadableDatabase();
         int numRows = (int) DatabaseUtils.queryNumEntries(db,EVENTS_TABLE_NAME);
         return numRows;
         }

    public Integer deleteEvent(String id) {

         SQLiteDatabase db = this.getWritableDatabase();
         return db.delete("events","eventid = ?", new String[]{id});


    }
    public ArrayList<SearchResultBean> getAllEvents(){
         ArrayList<SearchResultBean> array_list = new ArrayList<SearchResultBean>();
         SQLiteDatabase db = this.getReadableDatabase();
         Cursor res = db.rawQuery("select * from events",null);
         res.moveToFirst();
         while(!res.isAfterLast()){
             SearchResultBean curr = new SearchResultBean();
             curr.setEventid(res.getString(res.getColumnIndex(EVENTS_COL_ID)));
             curr.setDateAndTime(res.getString(res.getColumnIndex(EVENTS_COL_DATE)));
             curr.setEventName(res.getString(res.getColumnIndex(EVENTS_COL_NAME)));
             curr.setCategroy(res.getString(res.getColumnIndex(EVENTS_COL_TYPE)));
             curr.setVenueName(res.getString(res.getColumnIndex(EVENTS_COL_VENUE)));
             array_list.add(curr);
             res.moveToNext();

         }
         res.close();
         return array_list;
    }

    public boolean contains(String id){

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from events",null);
        res.moveToFirst();
        while(!res.isAfterLast()){
            String curr = res.getString(res.getColumnIndex(EVENTS_COL_ID));
            if(curr.equals(id))return true;
            res.moveToNext();
        }
        res.close();
        return false;

    }






}
