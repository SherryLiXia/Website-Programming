package com.example.xiali.myapplication4;

public class Searchbean {
    private String keyword;
    private String remote;
    private String distance;
    private String category;
    private String from;
    private String mileorkm;
    private Double lat;
    private Double lng;

    public Searchbean(){
        keyword="";
        remote="";
        distance="10";
        category="";
        from="";
        mileorkm="";
        lat=0.0;
        lng=0.0;
    }

    public void setKeyword(String keyword){
        this.keyword = keyword;
    }
    public String getKeyword(){
        return this.keyword;
    }
    public void setRemote(String Remote){
        this.remote = Remote;
    }
    public String getRemote(){
        return this.remote;
    }
    public void setDistance(String distance){
        this.distance= distance;
    }
    public String getDistance(){
        return this.distance;
    }
    public void setCategory(String category){
        this.category = category;
    }
    public String getCategory(){
        return this.category;
    }
    public void setFrom(String from){
        this.from = from;
    }
    public String getFrom(){
        return this.from;
    }
    public void setMileorkm(String mileorkm){
        this.mileorkm = mileorkm;
    }
    public String getMileorkm(){
        return this.mileorkm;
    }
    public void setLat(Double lat){this.lat=lat;}
    public Double getLat(){return this.lat;}
    public void setLng(Double lng){this.lng=lng;}
    public Double getLng(){return this.lng;}

}
