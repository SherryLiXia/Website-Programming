package com.example.xiali.myapplication4;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

class MyViewHolder2 extends RecyclerView.ViewHolder{
    public TextView eventname;
    public TextView musician;
    public TextView dateandtime;
    public TextView type;
    public MyViewHolder2(View itemView){
        super(itemView);
        eventname=(TextView) itemView.findViewById(R.id.nameandtime);
        musician =(TextView) itemView.findViewById(R.id.artists);
        dateandtime=(TextView) itemView.findViewById(R.id.date_and_time_up);
        type=(TextView) itemView.findViewById(R.id.type);

    }
}
public class Adapterforupcoming extends RecyclerView.Adapter <RecyclerView.ViewHolder>  {
    private Context context;
    List<UpcomingBean> result;
    public Adapterforupcoming(List<UpcomingBean> result){

        this.result = result;


    }
    public int getItemViewType(int position){
        return 0;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int ViewType){
        this.context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.card_view,parent,false);
        return new MyViewHolder2(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        final MyViewHolder2 viewHolder2 = (MyViewHolder2) viewHolder;
        final UpcomingBean item = result.get(i);
        viewHolder2.setIsRecyclable(false);
        viewHolder2.eventname.setText(item.getEventname());
        viewHolder2.dateandtime.setText(item.getDateandtime());
        viewHolder2.musician.setText(item.getArtists());
        viewHolder2.type.setText(item.getType());
        viewHolder2.eventname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String eventurl=item.getUrl();
                Uri uri = Uri.parse(eventurl);
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                v.getContext().startActivity(intent);
            }
        });





    }
    @Override
    public int getItemCount() {
        return result.size();
    }



}
