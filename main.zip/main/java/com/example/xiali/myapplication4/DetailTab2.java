package com.example.xiali.myapplication4;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextPaint;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class DetailTab2 extends Fragment {
    private  String musicjson;
    private String sportjson;
    boolean music=false;
    boolean sport=false;
    private JSONparse jsoNparse=new JSONparse();
        @Nullable
        @Override
        public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            jsoNparse.execute("hi");

            return inflater.inflate(R.layout.detailtab2,container,false);
        }




    private class JSONparse extends AsyncTask<String,String,String> {


        private Map<String,String> detailmap = new HashMap<String,String>();

        private ProgressDialog pDialog;


        protected void onPreExecute() {
            super.onPreExecute();


            pDialog = new ProgressDialog(getActivity());
            pDialog.setMessage("Getting Data ...");
            pDialog.setCancelable(true);
            pDialog.show();
        }

        protected String doInBackground(String... params) {


            String detailjson = ConnectServer.getJson("http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/eventdetail");




            try{
                JSONObject detailJson= new JSONObject(detailjson);
                String category=detailJson.getJSONArray("classifications").getJSONObject(0).getJSONObject("segment").getString("name");
                if(category.equals("Sports"))sport=true;
                else if(category.equals("Music"))music=true;

            }catch(JSONException e){
                e.printStackTrace();
            }

            if(music) {
                musicjson = ConnectServer.getJson("http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/musician");
            }
            if(sport){
                sportjson=ConnectServer.getJson("http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/sports");
            }

            //music is not finish yet;


            //venuejson=ConnectServer.getJson("http://10.0.2.2:3000/venuedetail");
            //String text = ConnectServer.getJson("http://10.0.2.2:3000/upcoming01");
            //upcomingjson=ConnectServer.getJson("http://10.0.2.2:3000/upcoming02");


            //get JSON here;
            return musicjson;

        }

        @Override
        protected void onPostExecute(String detailjson) {
            LinearLayout.LayoutParams layoutParams=
                    new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
            //textView.setText(resultlist.toString());
            super.onPostExecute(detailjson);
            if (pDialog.isShowing()) pDialog.dismiss();
             if(music) {
                 try {
                     JSONArray musicJson = new JSONArray(musicjson);
                     LinearLayout container = (LinearLayout) getActivity().findViewById(R.id.addhere);
                     if (musicJson.length() >= 1) {
                         TextView musician1 = new TextView(getActivity());
                         JSONObject musician_ = musicJson.getJSONObject(0).getJSONObject("artists")
                                 .getJSONArray("items").getJSONObject(0);


                         musician1.setText(musician_.getString("name"));
                         musician1.setGravity(Gravity.CENTER);
                         container.addView(musician1);


                         LinearLayout layoutrow = new LinearLayout(getActivity());
                         layoutrow.setOrientation(LinearLayout.HORIZONTAL);
                         TextView name1 = new TextView(getActivity());
                         name1.setText("Name");
                         name1.setWidth(400);
                         TextPaint tp = name1.getPaint();
                         tp.setFakeBoldText(true);
                         layoutrow.addView(name1);
                         TextView name2 = new TextView(getActivity());
                         name2.setText(musician_.getString("name"));
                         layoutrow.addView(name2);
                         container.addView(layoutrow);

                         LinearLayout layoutrow2 = new LinearLayout(getActivity());
                         layoutrow2.setOrientation(LinearLayout.HORIZONTAL);
                         TextView ask = new TextView(getActivity());
                         ask.setText("Followers");
                         ask.setWidth(400);
                         tp = ask.getPaint();
                         tp.setFakeBoldText(true);
                         layoutrow2.addView(ask);
                         TextView ans = new TextView(getActivity());
                         ans.setText(musician_.getJSONObject("followers").getString("total"));
                         layoutrow2.addView(ans);
                         container.addView(layoutrow2);

                         layoutrow = new LinearLayout(getActivity());
                         layoutrow.setOrientation(LinearLayout.HORIZONTAL);
                         ask = new TextView(getActivity());
                         ask.setText("Popularity");
                         ask.setWidth(400);
                         tp = ask.getPaint();
                         tp.setFakeBoldText(true);
                         layoutrow.addView(ask);
                         ans = new TextView(getActivity());
                         ans.setText(musician_.getString("popularity"));
                         layoutrow.addView(ans);
                         container.addView(layoutrow);


                         layoutrow = new LinearLayout(getActivity());
                         layoutrow.setOrientation(LinearLayout.HORIZONTAL);
                         ask = new TextView(getActivity());
                         ask.setText("Check At");
                         ask.setWidth(400);
                         tp = ask.getPaint();
                         tp.setFakeBoldText(true);
                         layoutrow.addView(ask);
                         ans = new TextView(getActivity());
                         ans.setText("Spotify");
                         final String uris = musician_.getString("uri");

                         ans.setOnClickListener(new View.OnClickListener() {

                             @Override
                             public void onClick(View v) {

                                 Uri uri = Uri.parse(uris);
                                 Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                 getActivity().startActivity(intent);
                             }
                         });
                         layoutrow.addView(ans);
                         container.addView(layoutrow);


                         ImageView img1 = new ImageView(getActivity());
                         img1.setPadding(50,50,50,50);
                         String imgurl=musician_.getJSONArray("images").getJSONObject(0).getString("url");
                         Picasso.with(getContext()).load(imgurl).resize(800,800).into(img1);

                         container.addView(img1);




                     }
                     if (musicJson.length() >= 2) {


                         TextView musician1 = new TextView(getActivity());
                         JSONObject musician_ = musicJson.getJSONObject(1).getJSONObject("artists")
                                 .getJSONArray("items").getJSONObject(0);


                         musician1.setText(musician_.getString("name"));
                         musician1.setGravity(Gravity.CENTER);
                         container.addView(musician1);


                         LinearLayout layoutrow = new LinearLayout(getActivity());
                         layoutrow.setOrientation(LinearLayout.HORIZONTAL);
                         TextView name1 = new TextView(getActivity());
                         name1.setText("Name");
                         name1.setWidth(400);
                         TextPaint tp = name1.getPaint();
                         tp.setFakeBoldText(true);
                         layoutrow.addView(name1);
                         TextView name2 = new TextView(getActivity());
                         name2.setText(musician_.getString("name"));
                         layoutrow.addView(name2);
                         container.addView(layoutrow);

                         LinearLayout layoutrow2 = new LinearLayout(getActivity());
                         layoutrow2.setOrientation(LinearLayout.HORIZONTAL);
                         TextView ask = new TextView(getActivity());
                         ask.setText("Followers");
                         ask.setWidth(400);
                         tp = ask.getPaint();
                         tp.setFakeBoldText(true);
                         layoutrow2.addView(ask);
                         TextView ans = new TextView(getActivity());
                         ans.setText(musician_.getJSONObject("followers").getString("total"));
                         layoutrow2.addView(ans);
                         container.addView(layoutrow2);

                         layoutrow = new LinearLayout(getActivity());
                         layoutrow.setOrientation(LinearLayout.HORIZONTAL);
                         ask = new TextView(getActivity());
                         ask.setText("Popularity");
                         ask.setWidth(400);
                         tp = ask.getPaint();
                         tp.setFakeBoldText(true);
                         layoutrow.addView(ask);
                         ans = new TextView(getActivity());
                         ans.setText(musician_.getString("popularity"));
                         layoutrow.addView(ans);
                         container.addView(layoutrow);


                         layoutrow = new LinearLayout(getActivity());
                         layoutrow.setOrientation(LinearLayout.HORIZONTAL);
                         ask = new TextView(getActivity());
                         ask.setText("Check At");
                         ask.setWidth(400);
                         tp = ask.getPaint();
                         tp.setFakeBoldText(true);
                         layoutrow.addView(ask);
                         ans = new TextView(getActivity());
                         ans.setText("Spotify");
                         final String uris = musician_.getString("uri");

                         ans.setOnClickListener(new View.OnClickListener() {

                             @Override
                             public void onClick(View v) {

                                 Uri uri = Uri.parse(uris);
                                 Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                 getActivity().startActivity(intent);
                             }
                         });
                         layoutrow.addView(ans);
                         container.addView(layoutrow);


                         ImageView img1 = new ImageView(getActivity());
                         img1.setPadding(50,50,50,50);
                         String imgurl=musician_.getJSONArray("images").getJSONObject(0).getString("url");
                         Picasso.with(getContext()).load(imgurl).resize(800,800).into(img1);

                         container.addView(img1);

                     }

                 } catch (JSONException e) {
                     e.printStackTrace();

                 }
             } else if(sport){

                 String team1="";
                 String team2="";
                 try{
                     JSONArray sportJson =  new JSONArray(sportjson);

                     team1 =sportJson.getJSONObject(0).getJSONObject("queries").
                             getJSONArray("request").getJSONObject(0).getString("searchTerms");
                     team2 =sportJson.getJSONObject(1).getJSONObject("queries").
                             getJSONArray("request").getJSONObject(0).getString("searchTerms");

                     TextView sportname = new TextView(getActivity());
                     sportname.setText(team1);
                     sportname.setGravity(Gravity.CENTER);

                     LinearLayout container=(LinearLayout)getActivity().findViewById(R.id.addhere);
                     container.addView(sportname);

                     for(int i=0;i<8;i++) {

                         ImageView img1 = new ImageView(getActivity());
                         String imgurl=sportJson.getJSONObject(0).getJSONArray("items")
                                 .getJSONObject(i).getString("link");
                         Picasso.with(getContext()).load(imgurl).resize(800,500).into(img1);

                         container.addView(img1);
                     }
                     TextView sportname2 = new TextView(getActivity());
                     sportname2.setText(team2);
                     sportname2.setGravity(Gravity.CENTER);
                     container.addView(sportname2);

                     for(int i=0;i<8;i++) {

                         ImageView img1 = new ImageView(getActivity());
                         String imgurl=sportJson.getJSONObject(1).getJSONArray("items")
                                 .getJSONObject(i).getString("link");
                         Picasso.with(getContext()).load(imgurl).resize(800,500).into(img1);

                         container.addView(img1);
                     }



                 }catch(JSONException e){
                     e.printStackTrace();
                 }






             }else{

             }








        }

    }
}
