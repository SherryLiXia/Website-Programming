package com.example.xiali.myapplication4;

import java.util.EventListener;

public class SearchResultBean {
    private String categroy;
    private String eventName;
    private String venueName;
    private String dateAndTime;
    private String eventid;

    public SearchResultBean(){
        categroy="";
        eventName="";
        venueName="";
        dateAndTime="";
        eventid="";

    }
    public void setCategroy(String categroy){
        this.categroy=categroy;
    }
    public String getCategroy(){
        return categroy;
    }
    public void setEventName(String eventName){
        this.eventName=eventName;
    }
    public String getEventName(){
        return eventName;
    }
    public void setVenueName(String venueName){
        this.venueName=venueName;
    }
    public String getVenueName(){
        return venueName;
    }
    public void setDateAndTime(String dateAndTime){
        this.dateAndTime=dateAndTime;
    }
    public String getDateAndTime(){
        return dateAndTime;
    }
    public void setEventid(String eventid){this.eventid=eventid;}
    public String getEventid(){return eventid;}




}
