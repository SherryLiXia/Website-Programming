package com.example.xiali.myapplication4;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class DetailTab1 extends Fragment {
    private String detailjson;
    private JSONObject detailJSON;

    private TextView artistandteam;
    private TextView venue;
    private TextView time;
    private TextView category;
    private TextView price;
    private TextView ticket;
    private TextView buytickat;
    private  TextView seatmap;

    private JSONparse jsoNparse = new JSONparse();


    TextView testone;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.detailtab1,container,false);
        jsoNparse.execute("hi");

        artistandteam = (TextView)view.findViewById(R.id.artistandteam);










       /* try {
            detailJSON = new JSONObject(detailjson);
        }catch(JSONException e){
            e.printStackTrace();
        }


        */
      // att.setText("hahaha");


        return view;
    }

    public void onActivityCreated  (Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);




      artistandteam = (TextView)getActivity().findViewById(R.id.artistandteam);
      venue = (TextView)getActivity().findViewById(R.id.venueindetail);
      time = (TextView)getActivity().findViewById(R.id.timeindetail);
      category=(TextView)getActivity().findViewById(R.id.categoryindetail);
      price = (TextView)getActivity().findViewById(R.id.princeindetail);
      ticket = (TextView)getActivity().findViewById(R.id.ticketstatusindetail);
      buytickat = (TextView) getActivity().findViewById(R.id.buyticketat);
      seatmap =(TextView) getActivity().findViewById(R.id.seatmap);








    }

    private class JSONparse extends AsyncTask<String,String,String> {


        private Map<String,String> detailmap = new HashMap<String,String>();

        private ProgressDialog pDialog;


        protected void onPreExecute() {
            super.onPreExecute();


            pDialog = new ProgressDialog(getActivity());
            pDialog.setMessage("Getting Data ...");
            pDialog.setCancelable(true);
            pDialog.show();
        }

        protected String doInBackground(String... params) {

            detailjson = ConnectServer.getJson("http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/eventdetail");

            //musicjson = ConnectServer.getJson("http://10.0.2.2:3000/musician");

            //music is not finish yet;

            //sportsjson=ConnectServer.getJson("http://10.0.2.2:3000/sports");
            //venuejson=ConnectServer.getJson("http://10.0.2.2:3000/venuedetail");
            //String text = ConnectServer.getJson("http://10.0.2.2:3000/upcoming01");
            //upcomingjson=ConnectServer.getJson("http://10.0.2.2:3000/upcoming02");

            String text = ConnectServer.getJson("http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/upcoming01");

            //get JSON here;
            return detailjson;

        }

        @Override
        protected void onPostExecute(String detailjson) {

            //textView.setText(resultlist.toString());
            super.onPostExecute(detailjson);
            if (pDialog.isShowing()) pDialog.dismiss();

            try {
                detailJSON = new JSONObject(detailjson);
            }catch(JSONException e){
                e.printStackTrace();
            }
            try {

                if(detailJSON.has("name"))
                    artistandteam.setText(detailJSON.getString("name"));
                if(detailJSON.has("_embedded")&&detailJSON.getJSONObject("_embedded").has("venues")) {
                    String venue1 = detailJSON.getJSONObject("_embedded").getJSONArray("venues").getJSONObject(0).getString("name");
                    venue.setText(venue1);
                }
                if(detailJSON.has("dates")) {
                    if(detailJSON.getJSONObject("dates").has("start")&&detailJSON.getJSONObject("dates").getJSONObject("start").has("localDate")) {
                        String time1 = detailJSON.getJSONObject("dates").getJSONObject("start").getString("localDate")
                                + " " + detailJSON.getJSONObject("dates").getJSONObject("start").getString("localTime");
                        time.setText(time1);
                    }
                    if(detailJSON.getJSONObject("dates").has("status")) {
                        //String category1=detailJSON.getJSONObject("");
                        String status = detailJSON.getJSONObject("dates").getJSONObject("status").getString("code");
                        ticket.setText(status);

                    }
                }
                if(detailJSON.has("classifications")){
                    String category1 = detailJSON.getJSONArray("classifications").getJSONObject(0).getJSONObject("segment").getString("name");
                    category1=category1+"|"+ detailJSON.getJSONArray("classifications").getJSONObject(0).getJSONObject("genre").getString("name");
                    category.setText(category1);

                }
                if(detailJSON.has("seatmap")){
                    final String seatmap1=detailJSON.getJSONObject("seatmap").getString("staticUrl");
                    seatmap.setText("View Here");
                    seatmap.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Uri uri = Uri.parse(seatmap1);
                            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                            getActivity().startActivity(intent);
                        }
                    });
                }
                if(detailJSON.has("url")){
                    final String buytickat1 = detailJSON.getString("url");
                    buytickat.setText("TicketMaster");

                    buytickat.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Uri uri = Uri.parse(buytickat1);
                            Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                            getActivity().startActivity(intent);
                        }
                    });

                }
                if(detailJSON.has("priceRanges")){
                    String price1 = "$"+detailJSON.getJSONArray("priceRanges").getJSONObject(0).getString("min")
                            +" ~ $"+detailJSON.getJSONArray("priceRanges").getJSONObject(0).getString("max");
                    price.setText(price1);
                }



            }catch(JSONException e){
                e.printStackTrace();
            }



        }

    }



}