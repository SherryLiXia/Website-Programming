package com.example.xiali.myapplication4;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class DetailTab3 extends Fragment implements OnMapReadyCallback {

    private String venuejson;
    private JSONparse jsoNparse = new JSONparse();

    private TextView name;
    private TextView address;
    private TextView city;
    private TextView phonenumber;
    private TextView openhour;
    private TextView generalrule;
    private TextView childrule;
    private GoogleMap mgoogleMap;
    private MapView mapView;
    private View mview;


    @Nullable
    @Override

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        mview=inflater.inflate(R.layout.detailtab3,container,false);

        name=(TextView)mview.findViewById(R.id.venuename);
        address=(TextView)mview.findViewById(R.id.venueaddress);
        city=(TextView)mview.findViewById(R.id.city);
        phonenumber=(TextView)mview.findViewById(R.id.phonenumber);
        openhour=(TextView)mview.findViewById(R.id.openhour);
        generalrule=(TextView)mview.findViewById(R.id.generalrule);
        childrule=(TextView)mview.findViewById(R.id.childrule);




        jsoNparse.execute("hi");

        //mapView = (MapView) mview.findViewById(R.id.mapview);
       // mapView.onCreate(savedInstanceState);

       // mapView.getMapAsync(this);











        return mview;
    }





    @Override
    public void onMapReady(GoogleMap googleMap) {
        // Add a marker in Sydney, Australia,
        // and move the map's camera to the same location.


        mgoogleMap = googleMap;
        mgoogleMap.getUiSettings().setZoomControlsEnabled(true);
        googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        LatLng sydney = new LatLng(-33.852, 151.211);
        googleMap.addMarker(new MarkerOptions().position(sydney)
                .title("Marker in Sydney"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }
/*
   // @Override
  //  public void onResume() {
        //super.onResume();
      //  mapView.onResume();
    //}

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }



*/

    private class JSONparse extends AsyncTask<String,String,String> {


        private Map<String,String> detailmap = new HashMap<String,String>();

        private ProgressDialog pDialog;


        protected void onPreExecute() {
            super.onPreExecute();


            pDialog = new ProgressDialog(getActivity());
            pDialog.setMessage("Getting Data ...");
            pDialog.setCancelable(true);
            pDialog.show();
        }

        protected String doInBackground(String... params) {

            //detailjson = ConnectServer.getJson("http://10.0.2.2:3000/eventdetail");

            //musicjson = ConnectServer.getJson("http://10.0.2.2:3000/musician");

            //music is not finish yet;

            //sportsjson=ConnectServer.getJson("http://10.0.2.2:3000/sports");
            venuejson=ConnectServer.getJson("http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/venuedetail");
            //String text = ConnectServer.getJson("http://10.0.2.2:3000/upcoming01");
            //upcomingjson=ConnectServer.getJson("http://10.0.2.2:3000/upcoming02");


            //get JSON here;
            return venuejson;

        }

        @Override
        protected void onPostExecute(String detailjson) {

            //textView.setText(resultlist.toString());
            super.onPostExecute(detailjson);
            if (pDialog.isShowing()) pDialog.dismiss();
            try{
                JSONObject venueJSON = new JSONObject(venuejson);
                if(venueJSON.has("name")) {
                    String nametxt = venueJSON.getString("name");
                    name.setText(nametxt);
                }

                if(venueJSON.has("city")) {
                    String citytxt = venueJSON.getJSONObject("city").getString("name");
                    city.setText(citytxt);
                }

                if(venueJSON.has("address")&&venueJSON.getJSONObject("address").has("line1")) {
                    String addtxt = venueJSON.getJSONObject("address").getString("line1");
                    address.setText(addtxt);
                }

                if(venueJSON.has("boxOfficeInfo")&&venueJSON.getJSONObject("boxOfficeInfo").has("phoneNumberDetail")) {
                    String phonetxt = venueJSON.getJSONObject("boxOfficeInfo").getString("phoneNumberDetail");
                    phonenumber.setText(phonetxt);
                }

                if(venueJSON.has("boxOfficeInfo")&&venueJSON.getJSONObject("boxOfficeInfo").has("openHoursDetail")) {
                    String opentxt = venueJSON.getJSONObject("boxOfficeInfo").getString("openHoursDetail");
                    openhour.setText(opentxt);
                }

                if(venueJSON.has("generalInfo")&&venueJSON.getJSONObject("generalInfo").has("generalRule")) {
                    String generaltxt = venueJSON.getJSONObject("generalInfo").getString("generalRule");
                    generalrule.setText(generaltxt);
                }

                if(venueJSON.has("generalInfo")&&venueJSON.getJSONObject("generalInfo").has("childRule")) {
                    String childtxt = venueJSON.getJSONObject("generalInfo").getString("childRule");
                    childrule.setText(childtxt);
                }


            }catch(JSONException e){
                e.printStackTrace();
            }

            //do something here;





        }

    }





}