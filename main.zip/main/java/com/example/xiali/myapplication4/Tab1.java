package com.example.xiali.myapplication4;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.xiali.myapplication4.Retrofit.IMyService;
import com.rengwuxian.materialedittext.MaterialEditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import io.reactivex.disposables.CompositeDisposable;

public  class Tab1 extends Fragment {

    private final int REQUEST_LOCATION_PERMISSION = 1;
    TextView txt_create_account;
    MaterialEditText keyworD,remotE,distancE;
    Button search_button;
    Button clear_button;
    AutoCompleteTextView keyword;
    EditText distance;
    EditText remote;
    Double lat;
    Double lng;
    RadioButton remote_radio;
    private TextView selectedText;
    private AutoSuggestAdapter autoSuggestAdapter;
    private Handler handler;
    private static final int TRIGGER_AUTO_COMPLETE = 100;
    private static final long AUTO_COMPLETE_DELAY = 300;
    private ArrayList<String> resultlist = new ArrayList<String>();




    CompositeDisposable compositeDisposable = new CompositeDisposable();
    IMyService iMyService;

    @SuppressLint("WrongViewCast")
    @Nullable
    @Override
    public View onCreateView (@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.tab1,container,false);


        search_button = (Button)view.findViewById(R.id.search_button);
        clear_button = (Button)view.findViewById(R.id.clear);
        keyword = (AutoCompleteTextView)view.findViewById(R.id.keyword);
        distance = (EditText)view.findViewById(R.id.distance);
        remote =(EditText)view.findViewById(R.id.remote);
        remote_radio=(RadioButton)view.findViewById(R.id.radioButton2);
        RadioGroup radioGroup = (RadioGroup)view.findViewById(R.id.radiogroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroupListener());
        selectedText =(TextView)view.findViewById(R.id.selected_item);
        autoSuggestAdapter = new AutoSuggestAdapter(getContext(),android.R.layout.simple_dropdown_item_1line);
        keyword.setThreshold(2);
        keyword.setAdapter(autoSuggestAdapter);
        keyword.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedText.setText(autoSuggestAdapter.getObject(position));
            }
        });
        keyword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                handler.removeMessages(TRIGGER_AUTO_COMPLETE);
                handler.sendEmptyMessageDelayed(TRIGGER_AUTO_COMPLETE,AUTO_COMPLETE_DELAY);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }


        });
        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if(msg.what==TRIGGER_AUTO_COMPLETE){
                    if (!TextUtils.isEmpty(keyword.getText())) {
                        callAPI();
                    }
                }
                return false;
            }
        });




        lat = getArguments().getDouble("lat");
        lng = getArguments().getDouble("lng");
        //get successfully


        return view;
    }
    public void onActivityCreated (Bundle savedInstanceState){

        super.onActivityCreated(savedInstanceState);
        //Spinner spinner = (Spinner) getView().findViewById()


        search_button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Spinner spinner = (Spinner)getView().findViewById(R.id.spinner);
                String category = spinner.getSelectedItem().toString();
                if(category.equals("All")) {
                    category="";
                } else if(category.equals("Music"))category="KZFzniwnSyZfZ7v7nJ";
                else if(category.equals("Sports"))category="KZFzniwnSyZfZ7v7nE";
                else if(category.equals("Film"))category="KZFzniwnSyZfZ7v7nn";
                else if(category.equals("Miscellaneous"))category="KZFzniwnSyZfZ7v7n1";
                else category="KZFzniwnSyZfZ7v7na";
                //get the item of category

                Spinner spinner2 = (Spinner)getView().findViewById(R.id.spinner2);
                String morkm = spinner2.getSelectedItem().toString();
                if(morkm.equals("Miles"))morkm="miles";
                else if(morkm.equals("Kilometers"))morkm="kilometers";
                //get mile or km

                RadioGroup radioGroup = (RadioGroup)getView().findViewById(R.id.radiogroup);
                int selectedId=radioGroup.getCheckedRadioButtonId();
                RadioButton radioButton=(RadioButton)getView().findViewById(selectedId);
                String radioselected = radioButton.getText().toString();
                //get Radio selected item











                Searchbean searchbean = new Searchbean();
                searchbean.setKeyword(keyword.getText().toString());
                searchbean.setCategory(category);
                searchbean.setDistance(distance.getText().toString());
                searchbean.setFrom(radioselected);
                searchbean.setRemote(remote.getText().toString());
                searchbean.setMileorkm(morkm);
                searchbean.setLat(lat);
                searchbean.setLng(lng);

                boolean valid = true;
                if(keyword.getText().toString().length()==0){
                    valid=false;
                    TextView error1 = (TextView)getActivity().findViewById(R.id.error1);
                    error1.setVisibility(View.VISIBLE);
                }else{
                    TextView error1 = (TextView)getActivity().findViewById(R.id.error1);
                    error1.setVisibility(View.INVISIBLE);

                }
                if(radioselected.equals("Current Location")==false&&remote.getText().toString().length()==0){
                    valid=false;
                    TextView error2 = (TextView)getActivity().findViewById(R.id.error2);
                    error2.setVisibility(View.VISIBLE);

                }else{
                    if(keyword.getText().toString().length()!=0)valid=true;

                    TextView error2 = (TextView)getActivity().findViewById(R.id.error2);
                    error2.setVisibility(View.INVISIBLE);

                }


                if(valid) {
                    ConnectServer.submitform(searchbean);


                    Intent intent = new Intent();
                    intent.setClass(getActivity(), SearchResultActivity.class);
                    startActivity(intent);
                }





            }










        });

        clear_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Spinner spinner = (Spinner)getView().findViewById(R.id.spinner);
                Spinner spinner2 = (Spinner)getView().findViewById(R.id.spinner2);
                RadioGroup radioGroup = (RadioGroup)getView().findViewById(R.id.radiogroup);
                TextView error1 = (TextView)getActivity().findViewById(R.id.error1);
                error1.setVisibility(View.INVISIBLE);
                TextView error2 = (TextView)getActivity().findViewById(R.id.error2);
                error2.setVisibility(View.INVISIBLE);
                keyword.setText("");
                distance.setText("");
                remote.setText("");
                spinner.setSelection(0);
                spinner2.setSelection(0);
                RadioButton radioButton = (RadioButton)getView().findViewById(R.id.radioButton);
                radioGroup.clearCheck();
                radioGroup.check(R.id.radioButton);






            }
        });













    }
    class RadioGroupListener implements  RadioGroup.OnCheckedChangeListener{
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedid){
            switch (checkedid){
                case R.id.radioButton:
                    remote.setEnabled(false);
                    break;
                case R.id.radioButton2:
                    remote.setEnabled(true);
                    break;
            }
        }
    }

    private void callAPI(){


        new Thread() {

            public void run() {

                resultlist=new ArrayList<>();
                String keywordlist = ConnectServer.getJson("http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/keyword?keyword=" + keyword.getText().toString());

                try {
                    JSONObject result = new JSONObject(keywordlist);
                    if (result.has("_embedded") && result.getJSONObject("_embedded").has("attractions")) {
                        JSONArray attractions = result.getJSONObject("_embedded").getJSONArray("attractions");
                        for (int i = 0; i < attractions.length(); i++) {
                            String name = attractions.getJSONObject(0).getString("name");
                            resultlist.add(name);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }


        }.start();
        autoSuggestAdapter.setData(resultlist);
        autoSuggestAdapter.notifyDataSetChanged();
    }







}
