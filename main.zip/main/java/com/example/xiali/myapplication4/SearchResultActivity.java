package com.example.xiali.myapplication4;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SearchResultActivity extends AppCompatActivity {
    private JSONparse jsonParseAsyncTask=new JSONparse();
    private TextView textView;
    private RecyclerView list;
    private RecyclerView.LayoutManager layoutManager;
    private Button back_button;
    private Context context;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_result);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        context = this;




        list=(RecyclerView)findViewById(R.id.recycler);
        list.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        list.setLayoutManager(layoutManager);

        String url="http://homework8-env.vkpfac3hpp.us-east-2.elasticbeanstalk.com/event";
        jsonParseAsyncTask.execute(url);






    }

    private class JSONparse extends AsyncTask<String,String,String>{
        private List<SearchResultBean> resultlist=new ArrayList<SearchResultBean>();

        private ProgressDialog pDialog;






        protected void onPreExecute(){
            super.onPreExecute();


            pDialog = new ProgressDialog(SearchResultActivity.this);
            pDialog.setMessage("Getting Data ...");
            pDialog.setCancelable(true);
            pDialog.show();
        }
        protected String doInBackground(String... params){

            String jsons=ConnectServer.getJson(params[0]);
            //get JSON here;
            return jsons;

        }
        @Override
        protected void onPostExecute(String jsons){

            JSONObject eventjson=new JSONObject();
            try {
                eventjson = new JSONObject(jsons);
            }catch(JSONException e){
                Log.e("JSON PARSER","Error parsing");
            }

            if(eventjson!=null){
               resultlist = new ArrayList<SearchResultBean>();
                try{
                    JSONObject embedded = eventjson.getJSONObject("_embedded");
                    JSONArray events =embedded.getJSONArray("events");
                    for(int i=0;i< events.length();i++){
                        JSONObject current_event = events.optJSONObject(i);
                        SearchResultBean current = new SearchResultBean();
                        current.setEventName(current_event.getString("name"));
                        String date = current_event.getJSONObject("dates").getJSONObject("start").getString("localDate");
                        date = date+" ";
                        date = date+current_event.getJSONObject("dates").getJSONObject("start").getString("localTime");
                        current.setDateAndTime(date);
                        current.setCategroy(current_event.getJSONArray("classifications").getJSONObject(0).getJSONObject("segment").getString("name"));
                        current.setVenueName(current_event.getJSONObject("_embedded").getJSONArray("venues").getJSONObject(0).getString("name"));
                        current.setEventid(current_event.getString("id"));
                        resultlist.add(current);
                        //add beans to resultlist;
                        //textView.setText(resultlist.toString());

                    }
                }catch(JSONException e){
                    e.printStackTrace();
                }
                //textView.setText(resultlist.toString());
                super.onPostExecute(jsons);
                if(pDialog.isShowing())pDialog.dismiss();

                MyAdapter adapter = new MyAdapter(resultlist, context);
                list.setAdapter(adapter);
                if(resultlist.size()==0){

                    ViewGroup.LayoutParams params=list.getLayoutParams();
                    params.height=200;
                    list.setLayoutParams(params);
                    TextView textView = (TextView) findViewById(R.id.norecord);
                    textView.setText("No Records");
                    textView.setVisibility(View.VISIBLE);

                }
                else{
                    TextView textView = (TextView) findViewById(R.id.norecord);
                    textView.setVisibility(View.INVISIBLE);
                }








            }

        }








    }

}
