package com.example.xiali.myapplication4;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class Tab2 extends Fragment {

    private RecyclerView list;
    private RecyclerView.LayoutManager layoutManager;
    private Context context;
    @Nullable
    @Override

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.tab2,container,false);
        context = getContext();

        list=(RecyclerView)view.findViewById(R.id.recycler2);
        list.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(context);
        list.setLayoutManager(layoutManager);


        MyAdapter2 adapter = new MyAdapter2(context);
        list.setAdapter(adapter);





        return view;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            //Write down your refresh code here, it will call every time user come to this fragment.
            //If you are using listview with custom adapter, just call notifyDataSetChanged().
            MyAdapter2 adapter = new MyAdapter2(context);
            list.setAdapter(adapter);
        }
    }


}
