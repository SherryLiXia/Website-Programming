package com.example.xiali.myapplication4;

public class UpcomingBean {
    private String eventname;
    private String artists;
    private String dateandtime;
    private String type;
    private String url;
    public UpcomingBean(){
        eventname="";
        artists="";
        dateandtime="";
        type="";
        url="";
    }
    public void setEventname(String eventname){
        this.eventname = eventname;
    }
    public String getEventname(){
        return this.eventname;
    }

    public void setArtists(String artists){
        this.artists= artists;
    }
    public String getArtists(){
        return this.artists;
    }

    public void setDateandtime(String dateandtime){
        this.dateandtime= dateandtime;
    }
    public String getDateandtime(){
        return this.dateandtime;
    }

    public void setType(String type){
        this.type= type;
    }
    public String getType(){
        return this.type;
    }

    public void setUrl(String url){this.url= url;}
    public String getUrl(){return url;}



}
