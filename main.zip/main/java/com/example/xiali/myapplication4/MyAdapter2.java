package com.example.xiali.myapplication4;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

class MyViewHolder3 extends RecyclerView.ViewHolder{
    public TextView eventName;
    public TextView venueName;
    public TextView dateAndTime;
    public ImageView category;
    public ImageView favorite;
    public LinearLayout textpart;

    //public RelativeLayout button;
    public MyViewHolder3(View itemView){
        super(itemView);
        eventName = (TextView)itemView.findViewById(R.id.eventName);
        venueName = (TextView)itemView.findViewById(R.id.venue_name);
        dateAndTime = (TextView)itemView.findViewById(R.id.date_and_time);
        //button=(RelativeLayout)itemView.findViewById(R.id.favorite);
        category =(ImageView)itemView.findViewById(R.id.Category_image);
        favorite=(ImageView)itemView.findViewById(R.id.favorite);
        textpart=(LinearLayout)itemView.findViewById(R.id.textpart);

    }
}


public class  MyAdapter2  extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context context;
    List<SearchResultBean> results;
    private DbHelper dbHelper;
    public MyAdapter2(Context context){
        this.context = context;

        dbHelper = new DbHelper(context);
        results=dbHelper.getAllEvents();


    }
    public int getItemViewType(int position){
        return 0;
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int ViewType){
        this.context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.item_view,parent,false);
        return new MyViewHolder3(view);
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        final MyViewHolder3 viewHolder1 = (MyViewHolder3) viewHolder;
        final SearchResultBean item = results.get(i);
        viewHolder1.setIsRecyclable(false);
        viewHolder1.eventName.setText(item.getEventName());
        viewHolder1.venueName.setText(item.getVenueName());
        viewHolder1.dateAndTime.setText(item.getDateAndTime());
        if(item.getCategroy().equals("Sports"))viewHolder1.category.setImageResource(R.drawable.sport_icon);
        else if(item.getCategroy().equals("Music"))viewHolder1.category.setImageResource(R.drawable.music_icon);
        else if(item.getCategroy().equals("Film"))viewHolder1.category.setImageResource(R.drawable.film_icon);
        else if(item.getCategroy().equals("Miscellaneous"))viewHolder1.category.setImageResource(R.drawable.miscellaneous_icon);
        else viewHolder1.category.setImageResource(R.drawable.art_icon);


        if(dbHelper.contains(item.getEventid()))viewHolder1.favorite.setImageResource(R.drawable.favorite_red);
        else viewHolder1.favorite.setImageResource(R.drawable.outline_black);
        viewHolder1.favorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(dbHelper.contains(item.getEventid())){
                    viewHolder1.favorite.setImageResource(R.drawable.outline_black);
                    dbHelper.deleteEvent(item.getEventid());
                    //results.remove(viewHolder1.getAdapterPosition());
                    String show = item.getEventName()+"has been removed from favorite";
                    Toast.makeText(context, show, Toast.LENGTH_SHORT).show();



                }
                else {
                    dbHelper.insertEvent(item.getEventid(),
                    item.getEventName(),item.getCategroy(),item.getVenueName(),item.getDateAndTime());
                    viewHolder1.favorite.setImageResource(R.drawable.favorite_red);

                    String show = item.getEventName()+"has been added to favorite";
                    Toast.makeText(context, show, Toast.LENGTH_SHORT).show();


                }






                //simply change color first just test;

            }
        });
        viewHolder1.textpart.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                int index=viewHolder1.getAdapterPosition();
                String eventid=results.get(index).getEventid();
                //send eventid to the server;
                ConnectServer.submiteventid(eventid);







                Intent intent = new Intent(context,eventdetail.class);
                context.startActivity(intent);
            }
        });









    }

    @Override
    public int getItemCount() {
        return results.size();
    }



}
